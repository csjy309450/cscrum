#ifndef _DEBUG_H
#define _DEBUG_H

void debug(int level,const char *msg,...);
void setDebugLevel(int level);

#endif
